📦 GHOSTLINK INSTALL GUIDE

STEP 1: Upload ghost.js to your website’s root or static/js folder.

STEP 2: In the <head> of your website’s HTML, add this:

<script src="/path/to/ghost.js" defer></script>

✔️ If you’re using a static site builder (Wix, Squarespace, WordPress), find a “custom code” or “header injection” option in site settings and paste that line.

Done! GhostLink will now track and block bots accessing your site.
